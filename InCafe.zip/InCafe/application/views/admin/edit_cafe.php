<div class="container-fluid">
    <h3><i class="fas fa-edit"></i>Edit Data Cafe</h3>

    <?php foreach($cafe as $cf) : ?>
        <form method="post" action="<?php echo base_url(). 'admin/data_cafe/update' ?>">
        <div class="form-group">
            <label>Nama Cafe</label>
            <input type="text" name="nama_cafe" class="form-control" value="<?php echo $cf->nama_cafe ?>">
        </div>
        <div class="form-group">
            <label>Deskripsi</label>
            <input type="hidden" name="id_cafe" class="form-control" value="<?php echo $cf->id_cafe ?>">
            <input type="text" name="deskripsi_cafe" class="form-control" value="<?php echo $cf->deskripsi_cafe ?>">
        </div>
        <div class="form-group">
            <label>Kategori</label>
            <input type="text" name="kategori_cafe" class="form-control" value="<?php echo $cf->kategori_cafe ?>">
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <input type="text" name="alamat_cafe" class="form-control" value="<?php echo $cf->alamat_cafe ?>">
        </div>
        <div class="form-group">
            <label>No. Telepon</label>
            <input type="text" name="telepon_cafe" class="form-control" value="<?php echo $cf->telepon_cafe ?>">
        </div>
        <div class="form-group">
            <label>Halal/Non-Halal Cafe</label>
            <input type="text" name="halal_non" class="form-control" value="<?php echo $cf->halal_non ?>">
        </div>
        <div class="form-group">
            <label>Range Harga</label>
            <input type="text" name="range_harga" class="form-control" value="<?php echo $cf->range_harga ?>">
        </div>
        <button type="submit" class="btn btn-primary btn-sm">Kembali</button>
        <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
        </form>
    <?php endforeach; ?>
</div>