<div class="container-fluid">
    <br><table class="table table-bordered">
        <tr class="table-info">
            <th>No</th>
            <th>Nama Cafe</th>
            <th>Deskripsi</th>
            <th>Kategori</th>
            <th>Alamat</th>
            <th>No. Telpon</th>
            <th>Halal/Non-Halal Cafe</th>
            <th>Range Harga</th>
            <th colspan="3">Aksi</th>
        </tr>
        <?php 
        $no=1;
        foreach($cafe as $cf) : ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $cf->nama_cafe ?></td>
            <td><?php echo $cf->deskripsi_cafe ?></td>
            <td><?php echo $cf->kategori_cafe ?></td>
            <td><?php echo $cf->alamat_cafe ?></td>
            <td><?php echo $cf->telepon_cafe ?></td>
            <td><?php echo $cf->halal_non ?></td>
            <td><?php echo $cf->range_harga ?></td>
            <td><div class="btn btn-success btn-sm"><i class="fas fa-search-plus"></i></div></td>
            <td><?php echo anchor('admin/data_cafe/edit/' .$cf->id_cafe, '<div class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></div>') ?></td>
            <td><?php echo anchor('admin/data_cafe/hapus/' .$cf->id_cafe, '<div class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></div>')?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#tambah_cafe"><i class="fas fa-plus fa-sm"></i><br>Tambah Cafe</button>
</div>

<!-- Modal -->
<div class="modal fade" id="tambah_cafe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Cafe</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url(). 'admin/data_cafe/tambah_aksi'; ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Nama Cafe</label>
            <input type="text" name="nama_cafe" class="form-control">
        </div>
        <div class="form-group">
            <label>Deskripsi Cafe</label>
            <input type="text" name="deskripsi_cafe" class="form-control">
        </div>
        <div class="form-group">
            <label>Kategori Cafe</label>
            <input type="text" name="kategori_cafe" class="form-control">
        </div>
        <div class="form-group">
            <label>Alamat Cafe</label>
            <input type="text" name="alamat_cafe" class="form-control">
        </div>
        <div class="form-group">
            <label>No. Telpon Cafe</label>
            <input type="text" name="telepon_cafe" class="form-control">
        </div>
        <div class="form-group">
            <label>Halal/Non-Halal</label>
            <input type="text" name="halal_non" class="form-control">
        </div>
        <div class="form-group">
            <label>Range Harga</label>
            <input type="text" name="range_harga" class="form-control">
        </div>
        <div class="form-group">
            <label>Foto</label><br>
            <input type="file" name="foto" class="form-control">
        </div>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>

