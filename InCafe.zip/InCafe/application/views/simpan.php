<br><br><br><br><div class="container-fluid">
    <h4>Simpan</h4>
    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>No</th>
            <th>Nama Cafe</th>
            <th>Jumlah</th>
        </tr>

        <?php
        $no=0;
        foreach ($this->cart->contents() as $items) :
        ?>
        <tr>
            <td>
                <?php echo $no++ ?>
            </td>
            <td><?php echo $items['name'] ?></td>
            <td><?php echo $items['qty'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>