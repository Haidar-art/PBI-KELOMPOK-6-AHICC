<?php 
class Model_cafe extends CI_Model{
    public function tampil_data(){
        return $this->db->get('daftar_cafe');
    }

    public function tambah_cafe($data, $table){
        $this->db->insert($table, $data);
    }

    //menjalankan data yang akan edit berdasarkan id cafe
    public function edit_cafe($where, $table){
        return $this->db->get_where($table, $where);
    }

    //edit data cafe
    public function update_data($where, $data, $table){
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    //hapus data cafe
    public function hapus_data($where, $table){
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function find($id){
        $result = $this->db->where('id_cafe', $id)->limit(1)->get('daftar_cafe');
        if($result->num_rows() > 0){
            return $result->row();
        } else {
            return array();
        }
    }
} 
?>