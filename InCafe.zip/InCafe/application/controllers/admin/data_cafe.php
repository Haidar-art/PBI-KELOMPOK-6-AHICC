<?php 
class Data_cafe extends CI_Controller{
    public function index(){
        $data['cafe'] = $this->model_cafe->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_cafe', $data);
        $this->load->view('templates_admin/footer');
    }

    // untuk tambah data cafe di admin
    public function tambah_aksi(){
        $nama_cafe              = $this->input->post('nama_cafe');
        $deskripsi_cafe         = $this->input->post('deskripsi_cafe');
        $kategori_cafe          = $this->input->post('kategori_cafe');
        $alamat_cafe            = $this->input->post('alamat_cafe');
        $telepon_cafe           = $this->input->post('telepon_cafe');
        $halal_non              = $this->input->post('halal_non');$range_harga      = $this->input->post('range_harga');
        // untuk upload file foto di tambah data cafe
        $foto                   = $_FILES['foto']['name'];
        if ($foto = ''){} else{
            // folder yang akan menyimpan upload an foto
            $config ['upload_path']     = './uploads';
            // type foto yang bisa di upload
            $config ['allowed_types']   ='jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('foto')){
                echo "Gambar gagal di upload!";
            } else{
                $foto = $this->upload->data('file_name');
            }
        }

        $data = array(
            'nama_cafe'         => $nama_cafe,
            'deskripsi_cafe'    => $deskripsi_cafe,
            'kategori_cafe'     => $kategori_cafe,
            'alamat_cafe'       => $alamat_cafe,
            'telepon_cafe'      => $telepon_cafe,
            'halal_non'         => $halal_non,
            'range_harga'       => $range_harga,
            'foto'              => $foto
        );

        //input ke dalam daftar_cafe melalui model_cafe
        $this->model_cafe->tambah_cafe($data, 'daftar_cafe');
        redirect('admin/data_cafe/index');
    }

    // untuk button edit di admin
    public function edit($id){
        $where          = array('id_cafe' => $id);
        $data['cafe']   = $this->model_cafe->edit_cafe($where, 'daftar_cafe')->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/edit_cafe', $data);
        $this->load->view('templates_admin/footer');
    }

    //update data cafe
    public function update(){
        $id                 = $this->input->post('id_cafe');
        $nama_cafe          = $this->input->post('nama_cafe');
        $deskripsi_cafe     = $this->input->post('deskripsi_cafe');
        $kategori_cafe      = $this->input->post('kategori_cafe');
        $alamat_cafe        = $this->input->post('alamat_cafe');
        $telepon_cafe       = $this->input->post('telepon_cafe');
        $halal_non          = $this->input->post('halal_non');
        $range_harga        = $this->input->post('range_harga');

        $data               = array(
            'nama_cafe'         => $nama_cafe,
            'deskripsi_cafe'    => $deskripsi_cafe,
            'kategori_cafe'     => $kategori_cafe,
            'alamat_cafe'       => $alamat_cafe,
            'telepon_cafe'      => $telepon_cafe,
            'halal_non'         => $halal_non,
            'range_harga'       => $range_harga
        );

        $where              = array(
            'id_cafe'   => $id
        );

        $this->model_cafe->update_data($where, $data, 'daftar_cafe');
        redirect ('admin/data_cafe/index');
    }

    public function hapus($id){
        $where = array('id_cafe' => $id);
        $this->model_cafe->hapus_data($where, 'daftar_cafe');
        redirect ('admin/data_cafe/index');
    }
}
?>