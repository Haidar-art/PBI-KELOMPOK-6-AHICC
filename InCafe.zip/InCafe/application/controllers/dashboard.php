<?php 
class Dashboard extends CI_Controller{
    public function index(){
        $data['cafe'] = $this->model_cafe->tampil_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('dashboard', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_ke_simpan($id){
        $cafe = $this->model_cafe->find($id);
        
        $data = array(
                'id'      => $cafe->id_cafe,
                'qty'     => 1,
                'name'    => $cafe->nama_cafe
        );
        
        $this->cart->insert($data);
        redirect('dashboard');
    }

    // public function detail_simpan(){
        // $this->load->view('templates/header');
        // $this->load->view('templates/sidebar');
        // $this->load->view('simpan');
        // $this->load->view('templates/footer');
    // }

    public function simpan(){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('simpan');
        $this->load->view('templates/footer');
    }
}
?>