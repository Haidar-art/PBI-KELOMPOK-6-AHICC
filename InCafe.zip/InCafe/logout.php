<?php
session_destroy();
echo "<script>alert('Anda telah keluar');</script>";
echo "<script>location='login.php';</script>";