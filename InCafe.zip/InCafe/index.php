<?php
session_start();
//koneksi ke database
$koneksi = new mysqli("localhost", "root", "", "incafe");
?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>InCafe</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
</head>

<body>

    <?php include 'menu.php'; ?>

    <!--konten-->
    <section class="konten">
        <div class="container">
            <h1>Informasi Cafe Terbaru</h1>
            <div class="row">
                <?php $ambil = $koneksi->query("SELECT * FROM tambah_cafe"); ?>
                <?php while ($cafe = $ambil->fetch_assoc()) { ?>
                    <div class="clearfix visible-xs-block"></div>
                    <div class="col-xs-6 col-sm-4">
                        <div class="thumbnail">
                            <img src="fotocafe/<?php echo $cafe['foto']; ?>" alt="" class="img-responsive">
                            <div class="caption">
                                <h3><?php echo $cafe['nama_toko_cafe']; ?></h3>
                                <a href="detail.php?id=<?php echo $cafe['id_tambah_cafe']; ?>" class="btn btn-primary">Detail</a>
                            </div>
                        </div>
                    </div>
            </div>
        <?php } ?>
        </div>
    </section>

</body>

</html>