<?php
session_start();
//koneksi ke database
$include("koneksi.php");
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>KATEGORI</title>

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- emoji reaction -->
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=62a9e344c15a8900199d23a8&product=inline-reaction-buttons" async="async"></script>

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <!-- Sidebar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand" href="index3.php"><strong>INCAFE</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index3.php">BERANDA<span class="sr-only">(current)</span></a>
                </li>
                <?php if (isset($_SESSION["user"])) : ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">KELUAR</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li class="nav-item"><a class="nav-link" href="view1.php">MASUK/DAFTAR</a></li>
                <?php endif ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="kategori.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">KATEGORI</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="kategori.php">CAFE TERMURAH</a>
                        <a class="dropdown-item" href="kategori2.php">CAFE TERMAHAL</a>
                        <a class="dropdown-item" href="cafeterjauh.php">CAFE TERJAUH</a>
                        <a class="dropdown-item" href="cafeterdekat.php">CAFE TERDEKAT</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="simpan1.php">SIMPAN</a>
                </li>
            </ul>
            <form action="pencarian1.php" method="get" class="form-inline my-2 my-lg-0">
                <input type="text" class="form-control mr-sm-2" name="keyword">
                <button class="btn btn-outline-dark my-2 my-sm-0">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                <br>
            </form>
        </div>
    </nav><br><br>

    <section class="konten">
        <div class="container">
            <div class="row">
                <?php $ambil = $koneksi->query("SELECT * FROM tambah_cafe WHERE id_kategori='2'"); ?>
                <?php while ($percafe = $ambil->fetch_assoc()) { ?>
                    <div class="card-body">
                        <div class="card ml-4" style="width: 16rem;">
                            <div class="thumbnail">
                                <img src="fotocafe/<?php echo $percafe['foto']; ?>" class="card-img-top" alt="">
                                <div class="caption mt-3">
                                    <center>
                                        <h5><?php echo $percafe['nama_toko_cafe']; ?></h5>
                                    </center>
                                    <div class="mb-3">
                                        <center>
                                            <a href="detailcafe.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class="btn btn-info btn-sm"><i class="fas fa-solid fa-eye"></i></a>
                                            <a href="save.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class=" btn btn-success btn-sm"><i class="fas fa-fw fa-bookmark"></i></a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <a href="index3.php" class="btn btn-primary"><i class="fas fa-solid fa-arrow-left"></i></a>