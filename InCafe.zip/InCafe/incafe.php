<?php
session_start();
//koneksi ke database
include("koneksi.php");
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

  <!-- Font Google -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;1,500;1,700&display=swap" rel="stylesheet">
  <!-- Menghubungkan style.css -->
  <link rel="stylesheet" href="style.css">

  <title>InCafe</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
    <div class="container">
      <a class="navbar-brand font-weight-bold" href="incafe.php">INCAFE</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item mx-2">
            <a class="nav-link" href="incafe.php">BERANDA</a>
          </li>
          <!-- jika sudah login(ada session user) -->
          <?php if (isset($_SESSION["user"])) : ?>
            <li><a href="logout.php">Logout</a></li>
            <!-- selain itu (blm login//blm ada session user) -->
          <?php else : ?>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#">DAFTAR/MASUK</a>
            </li>
          <?php endif ?>
          <li class="nav-item dropdown mx-2">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              KATEGORI
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Cafe Termahal</a>
              <a class="dropdown-item" href="#">Cafe Termurah</a>
          </li>
          <li class="nav-item mx-2">
            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">SIMPAN</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Cari cafe" aria-label="Search">
          <button class="btn btn-success my-2 my-sm-0" type="submit">CARI</button>
        </form>
      </div>
    </div>
  </nav>

  <div class="jumbotron">
    <div class="container">
      <center>
        <h1 class="display-4">Selamat Datang di InCafe!</h1>
      </center>
      <hr class="my-4">
      <p>Bingung mau mencari sebuah informasi tentang cafe? Atau mau tau cafe-cafe yang ada di Jakarta dan sekitarnya? Pas banget nih, InCafe hadir untuk membantu kamu mengenai semua hal itu! Yuk, jangan malu-malu berjelajah di InCafe, ya!</p>
      <a class="btn btn-primary btn-lg" href="#" role="button">Tentang Kami</a>
    </div>
  </div>

  <section class="konten">
    <div class="container">
      <h1>Rekomendasi Cafe</h1>
    </div>
  </section>





  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>

</html>