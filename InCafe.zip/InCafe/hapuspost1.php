<?php
session_start();
$id_tambah_cafe = $_GET["id"];
unset($_SESSION["simpan"][$id_tambah_cafe]);

echo "<script>alert('Data cafe di hapus dari Simpan');</script>";
echo "<script>location='simpan1.php';</script>";