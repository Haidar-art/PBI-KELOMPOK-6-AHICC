<?php
session_start();
include("koneksi.php");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login User</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
</head>

<body>
    <!--Navbar-->

    <nav class="navbar navbar-default">
        <div class="container">
            <ul class="nav navbar-nav">

                <li><a href="index3.php">Home</a></li>
                <!-- jika sudah login(ada session pelanggan) -->
                <?php if (isset($_SESSION["user"])) : ?>
                    <li><a href="logout.php">Logout</a></li>
                    <!-- selain itu (blm login//blm ada session pelanggan) -->
                <?php else : ?>
                    <li><a href="view.php">Login/Daftar</a></li>
                <?php endif ?>
                <li><a href="save.php">Simpan</a></li>
                <div class="container">
                    <form action="pencarian.php" method="get" class="navbar-form navbar-right">
                        <input type="text" class="form-control" name="keyword">
                        <button class="btn btn-primary">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                        <br>
                    </form>
                </div>

            </ul>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Login User</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password">
                            </div>
                            <button class="btn btn-primary" name="login">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    //jika ada tombol login(tombol login ditekan)
    if (isset($_POST["login"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];
        //lakukan query ngecek akun di tabel pelanggan di database
        $ambil = $koneksi->query("SELECT * FROM user
				WHERE email_user='$email' AND password='$password'");
        //ngitung akun yang terambil
        $akunyangcocok = $ambil->num_rows;
        //jika 1 akun yan cocok, maka diloginkan
        if ($akunyangcocok == 1) {
            while ($row = $ambil->fetch_assoc()) {
                if ($row['status'] == 'verified') {
                    //mendapatkan akun dalam bentuk array
                    $akun = $ambil->fetch_assoc();
                    //simpan di session pelanggan
                    $_SESSION["user"] = $akun;
                    echo "<script>alert('Anda berhasil login.');</script>";
                    echo "<script>location='index3.php';</script>";
                } else {
                    echo "<script>alert('Please verify your account');</script>";
                }
            }
        } else {
            //anda gagal login
            echo "<script>alert('anda gagal login, periksa akun Anda');</script>";
            echo "<script>location='login.php';</script>";
        }
    }

    ?>
</body>

<head>