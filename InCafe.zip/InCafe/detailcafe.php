<?php

include("koneksi.php");
?>

<?php
//mendapatkan id cafe
$id_tambah_cafe = $_GET["id"];

//query ambil data
$ambil = $koneksi->query("SELECT * FROM tambah_cafe WHERE id_tambah_cafe='$id_tambah_cafe'");
$detail = $ambil->fetch_assoc();

//echo "<prev>";
//print_r($detail);
//echo "</prev>";
?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DETAIL CAFE</title>

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- emoji reaction -->
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=62a9e344c15a8900199d23a8&product=inline-reaction-buttons" async="async"></script>
    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <!-- Sidebar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand" href="index3.php"><strong>INCAFE</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index3.php">BERANDA<span class="sr-only">(current)</span></a>
                </li>
                <?php if (isset($_SESSION["user"])) : ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">KELUAR</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li class="nav-item"><a class="nav-link" href="view1.php">MASUK/DAFTAR</a></li>
                <?php endif ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">KATEGORI</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">CAFE TERMURAH</a>
                        <a class="dropdown-item" href="#">CAFE TERMAHAL</a>
                        <a class="dropdown-item" href="#">CAFE TERJAUH</a>
                        <a class="dropdown-item" href="#">CAFE TERDEKAT</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index3.php">SIMPAN</a>
                </li>
            </ul>
            <form action="pencarian1.php" method="get" class="form-inline my-2 my-lg-0">
                <input type="text" class="form-control mr-sm-2" name="keyword">
                <button class="btn btn-outline-dark my-2 my-sm-0">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                <br>
            </form>
        </div>
    </nav><br><br>

    <section class="konten mt-4">
        <div class="container">
            <div class="alert alert-info" role="alert">
                <i class="fas fa-eye"></i><strong> Detail Cafe</strong>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-6">
                    <img src="fotocafe/<?php echo $detail["foto"]; ?>" alt="" class="img-responsive" style="width: 500px">
                </div>
                <div class="col-6">
                    <h2><strong><?php echo $detail["nama_toko_cafe"]; ?></strong></h2>
                    <p>Deskripsi: <br><?php echo $detail["deskripsi_cafe"]; ?></p>
                    <p>Telepon Cafe: <br><?php echo $detail["telepon_cafe"]; ?></p>
                    <p>Alamat: <br><?php echo $detail["alamat_cafe"]; ?></p>
                    <p>Halal/Non-Halal: <br><?php echo $detail["halal_cafe"]; ?></p>
                    <a href="index3.php" class="btn btn-primary"><i class="fas fa-solid fa-arrow-left"></i></a>
                </div>
            </div>
        </div>
    </section><br>


</body>

</html>

<center>
    <div class="sharethis-inline-reaction-buttons"></div>
</center>