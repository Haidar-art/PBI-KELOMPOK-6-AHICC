<?php
include("koneksi.php");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Daftar Pelanggan</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
</head>

<body>
    <div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />
                <br />
            </div>
        </div>
        <div class="row ">
            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <center><img src="fotocafe/Logo_InCafe.png" alt="centered image" height="350" width="350"> </center>

                <center>
                    <a href="daftar.php" class="btn btn-primary btn-lg">Register</a>
                    <a href="login.php" class="btn btn-primary btn-lg">Login</a>
                </center>
            </div>
        </div>
    </div>
</body>

</html>