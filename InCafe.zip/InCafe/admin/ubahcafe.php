<h2>Ubah Cafe</h2>

<?php
$ambil = $koneksi->query("SELECT * FROM tambah_cafe WHERE id_tambah_cafe='$_GET[id]'");
$pecah = $ambil->fetch_assoc();

//echo "<prev>";
//print_r($pecah);
//echo "</prev>";
?>

<?php
$datakategori = array();
$ambil = $koneksi->query("SELECT * FROM kategori");
while ($tiap = $ambil->fetch_assoc()) {
    $datakategori[] = $tiap;
}
?>

<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>Nama Cafe</label>
        <input type="text" class="form-control" name="nama" value="<?php echo $pecah['nama_toko_cafe']; ?>">
    </div>
    <div class="form-group">
        <label>Kategori</label>
        <select class="form-control" name="id_kategori">
            <option value="">Pilih Kategori</option>
            <?php foreach ($datakategori as $key => $value) : ?>
                <option value="<?php echo $value["id_kategori"] ?>" <?php if ($pecah["id_kategori"]==$value["id_kategori"]){ echo "selected"; } ?>>
                    <?php echo $value["nama_kategori"] ?>
                </option>
            <?php endforeach ?>
        </select>
    </div>
    <div class="form-group">
        <label>Deskripsi Cafe</label>
        <textarea class="form-control" name="deskripsi" rows="10"><?php echo $pecah['deskripsi_cafe']; ?>"</textarea>
    </div>
    <div class="form-group">
        <label>Telpon Cafe</label>
        <input type="text" class="form-control" name="telpon" value="<?php echo $pecah['telepon_cafe']; ?>">
    </div>
    <div class="form-group">
        <label>Alamat Cafe</label>
        <input type="text" class="form-control" name="alamat" value="<?php echo $pecah['alamat_cafe']; ?>">
    </div>
    <div class="form-group">
        <label>Halal/Non-Halal Cafe</label>
        <input type="text" class="form-control" name="halal" value="<?php echo $pecah['halal_cafe']; ?>">
    </div>
    <div class="form-group">
        <img src="../fotocafe/<?php echo $pecah['foto'] ?>" width="200">
    </div>
    <div class="form-group">
        <label>Ganti Foto</label>
        <input type="file" class="form-control" name="foto">
    </div>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Ubah</button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Cafe</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
    </div>
    <div class="modal-body">
        Sudah yakin dengan perubahannya?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button class="btn btn-primary" name="ubah">Ubah</button>
      </div>
    </div>
  </div>
</div>
</form>

<?php
if (isset($_POST['ubah'])) {
    $namafoto = $_FILES['foto']['name'];
    $lokasifoto = $_FILES['foto']['tmp_name'];
    //jika foto diubah
    if (!empty($lokasifoto)) {
        move_uploaded_file($lokasifoto, "../fotocafe/$namafoto");

        $koneksi->query("UPDATE tambah_cafe SET nama_toko_cafe='$_POST[nama]', id_kategori='$_POST[id_kategori]', deskripsi_cafe='$_POST[deskripsi]', telepon_cafe='$_POST[telpon]', alamat_cafe='$_POST[alamat]', halal_cafe='$_POST[halal]', foto='$namafoto'
        WHERE id_tambah_cafe='$_GET[id]'");
    } else {
        $koneksi->query("UPDATE tambah_cafe SET nama_toko_cafe='$_POST[nama]', id_kategori='$_POST[id_kategori]', deskripsi_cafe='$_POST[deskripsi]', telepon_cafe='$_POST[telpon]', alamat_cafe='$_POST[alamat]', halal_cafe='$_POST[halal]'
        WHERE id_tambah_cafe='$_GET[id]'");
    }

    echo "<script>location='index.php?halaman=tambah_cafe';</script>";
}
?>