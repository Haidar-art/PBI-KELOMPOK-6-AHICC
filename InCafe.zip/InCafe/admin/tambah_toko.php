<?php
$datakategori = array();
$ambil = $koneksi->query("SELECT * FROM kategori");
while ($tiap = $ambil->fetch_assoc()) {
    $datakategori[] = $tiap;
}
?>

<h2>Tambah Cafe</h2>

<form method="post" enctype="multipart/form-data">
        <div class="form-group">
                <label>Nama Cafe</label>
                <input type="varchar" class="form-control" name="nama">
        </div>
        <div class="form-group">
        <label>Kategori</label>
        <select class="form-control" name="id_kategori">
            <option value="">Pilih Kategori</option>
            <?php foreach ($datakategori as $key => $value) : ?>
                <option value="<?php echo $value["id_kategori"] ?>"><?php echo $value["nama_kategori"] ?></option>
            <?php endforeach ?>
        </select>
    </div>
        <div class="form-group">
                <label>Deskripsi</label>
                <textarea class="form-control" name="deskripsi" rows="10"></textarea>
        </div>
        <div class="form-group">
                <label>Alamat</label>
                <input type="varchar" class="form-control" name="alamat">
        </div>
        <div class="form-group">
                <label>Telepon</label>
                <input type="varchar" class="form-control" name="telepon">
        </div>
        <div class="form-group">
                <label>Foto Cafe</label>
                <input type="file" class="form-control" name="foto">
        </div>
        <div class="form-group">
                <label>Halal/Non-Halal</label>
                <input type="text" class="form-control" name="halal">
        </div>
        <div class="form-group">
                <label>Harga Menu</label>
                <input type="text" class="form-control" name="harga">
        </div>
        <button class="btn btn-primary" name="save">Simpan</button>
</form>

<?php
if (isset($_POST['save'])) {
        $nama = $_FILES['foto']['name'];
        $lokasi = $_FILES['foto']['name'];
        move_uploaded_file($lokasi, "../fotocafe/" . $nama);
        $koneksi->query("INSERT INTO tambah_cafe
    (nama_toko_cafe, deskripsi_cafe, alamat_cafe, telepon_cafe, halal_cafe, foto, id_kategori)
    VALUES ('$_POST[nama]', '$_POST[deskripsi]', '$_POST[alamat]', '$_POST[telepon]', '$_POST[halal]','$nama', '$_POST[id_kategori]')");

        echo "<div class='alert alert-info'>Data Tersimpan</div>";
        echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=tambah_cafe'>";
}
?>