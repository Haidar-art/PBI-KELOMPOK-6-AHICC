<?php
session_start();

echo "<pre>";
print_r($_SESSION['simpan']);
echo "</pre>"
?>

<!DOCTYPE html>
<html>
<head>
    <title>simpan</title>
    <link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<body>

<!--Navbar-->
<nav class="navbar navbar-default">
        <div class="container">
            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="simpan.php">Simpan</a></li>
            </ul>
        </div>
    </nav>

<section class="konten">
    <div class="container">
        <h1>Simpan</h1>
    </div>
</section>

</body>
</html>