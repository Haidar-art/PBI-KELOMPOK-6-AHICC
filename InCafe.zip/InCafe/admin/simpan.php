<h1>Saved</h1>
            <hr>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Cafe</th>
                        <th>Deskripsi Cafe</th>
                        <th>Telpon Cafe</th>
                        <th>Alamat Cafe</th>
                        <th>Foto Cafe</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $nomor=1; ?>
                    <?php foreach ($_SESSION["simpan"] as $id_tambah_cafe => $jumlah): ?>
                    
                    <?php
                    $ambil = $koneksi->query("SELECT * FROM tambah_cafe 
                        WHERE id_tambah_cafe='$id_tambah_cafe'");
                    $pecah = $ambil->fetch_assoc();
                    //echo "<pre>";
                    //print_r($pecah);
                    //echo "</pre>";
                    ?>

                    <tr>
                        <td><?php echo $nomor; ?></td>
                        <td><?php echo $pecah["nama_toko_cafe"]; ?></td>
                        <td><?php echo $pecah["deskripsi_cafe"]; ?></td>
                        <td><?php echo $pecah["telepon_cafe"]; ?></td>
                        <td><?php echo $pecah["alamat_cafe"]; ?></td>
                        <td>
                        <img src="../fotocafe/<?php echo $pecah['foto']; ?>" width="120">
                        </td>
                        <td>
                            <a href="hapuspost.php?id=<?php echo $id_tambah_cafe ?>" class="btn btn-danger btn-xs" >hapus</a>
                        </td>
                    </tr>
                    <?php $nomor++ ?>
                    <?php endforeach ?>
                </tbody>
            </table>
            <a href="index.php" class="btn btn-default">Kembali</a>
