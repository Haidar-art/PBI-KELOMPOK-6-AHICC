<h2>Tambah Pemilik Cafe</h2>

<form method="post" enctype="multipart/form-data">
        <div class="form-group">
                <label>Nama Cafe</label>
                <input type="varchar" class="form-control" name="nama">
        </div>
        <div class="form-group">
                <label>Pemilik Cafe</label>
                <input type="varchar" class="form-control" name="pemilik_cafe">
        </div>
        <div class="form-group">
                <label>Telepon</label>
                <input type="varchar" class="form-control" name="telepon">
        
                <button class="btn btn-primary" name="save">Simpan</button>
</form>

<?php
if (isset($_POST['save'])) {
        $koneksi->query("INSERT INTO admin_toko
    (nama_cafe, pemilik_cafe, no_telpon_pemilik)
    VALUES ('$_POST[nama]', '$_POST[pemilik_cafe]', '$_POST[telepon]')");

        echo "<div class='alert alert-info'>Data Tersimpan</div>";
        echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=admin_toko'>";
}
?>