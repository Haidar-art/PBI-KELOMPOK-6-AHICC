<h2>Selamat Datang Admin</h2>
<!--<pre><?php //print_r($_SESSION); 
            ?></pre>-->
            <div class="container" style="margin-top:20px">
                <div class="col-md-9">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Grafik Persentase Cafe Terpopuler</div>
                        <div class="panel-body">
                            <div id="mygraphh"></div>
                        </div>
                    </div>
                </div>
            </div>