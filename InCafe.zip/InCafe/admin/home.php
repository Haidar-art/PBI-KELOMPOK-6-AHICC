<h2>Selamat Datang Admin</h2>
<pre><?php print_r($_SESSION); ?></php>