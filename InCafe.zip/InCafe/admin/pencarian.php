<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>InCafe</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div class="container">
        <h2>Hasil Pencarian</h2>
    </div>
</body>