<?php
$ambil = $koneksi->query("SELECT * FROM admin_toko WHERE id_admin_toko='$_GET [id'");
$pecah = $ambil->fetch_assoc();

$koneksi->query("DELETE FROM admin_toko WHERE id_admin_toko='$_GET[id]'");
echo "<script>alert('Data cafe dihapus!');</script>";
echo "<script>location='index.php?halaman=admin_toko';</script>";
