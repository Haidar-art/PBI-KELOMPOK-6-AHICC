<?php
//menyambungkan ke database
$koneksi = mysqli_connect("localhost", "root", "", "epiz_32040290_incafe");

function query($query){
    global $koneksi;
    $result = mysqli_query($koneksi, "SELECT * FROM tambah_cafe");
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

function cari ($keyword){
    $query = "SELECT * FROM tambah_cafe WHERE nama_toko_cafe LIKE '%$keyword%'";
    return query($query);
}
