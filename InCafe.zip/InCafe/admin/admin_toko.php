<h2>Data Pemilik Toko</h2>
<table class="table table-bordered">
    <thead>
        <tr>
            <th class="text-center align-middle">No</th>
            <th class="text-center align-middle">Nama Cafe</th>
            <th class="text-center align-middle">Pemilik Cafe</th>
            <th class="text-center align-middle">No. Telpon Pemilik Cafe</th>
            <th class="text-center align-middle">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $nomor = 1; ?>
        <?php $ambil = $koneksi->query("SELECT * FROM admin_toko"); ?>
        <?php while ($pecah = $ambil->fetch_assoc()) { ?>
            <tr>
                <td class="text-center align-middle"><?php echo $nomor; ?></td>
                <td class="text-center align-middle"><?php echo $pecah['nama_cafe']; ?></td>
                <td class="text-center align-middle"><?php echo $pecah['pemilik_cafe']; ?></td>
                <td class="text-center align-middle"><?php echo $pecah['no_telpon_pemilik']; ?></td>
                <td class="text-center align-middle">
                    <a href="index.php?halaman=hapusdatacafe&id=<?php echo $pecah['id_admin_toko']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                </td>
            </tr>
            <?php $nomor++; ?>
        <?php } ?>
    </tbody>
</table>
<a href="index.php?halaman=tambah_pemilik_cafe" class="btn btn-primary">Tambah Pemilik Cafe</a>