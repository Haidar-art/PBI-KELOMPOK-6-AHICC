
<?php
$ambil = $koneksi->query("SELECT * FROM tambah_cafe WHERE id_tambah_cafe='$_GET [id'");
$pecah = $ambil->fetch_assoc();
$fotoproduk = $pecah['foto'];
if (file_exists("../foto/$fotocafe")) {
    unlink("../foto/$fotocafe");
}
$koneksi->query("DELETE FROM tambah_cafe WHERE id_tambah_cafe='$_GET[id]'");

echo "<div class='modal-body'>
Sudah yakin dengan perubahannya?
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>
<button class='btn btn-primary' name='ubah'>Ubah</button>
</div>
</div>
</div>
</div>";
echo "<script>location='index.php?halaman=tambah_cafe';</script>";
