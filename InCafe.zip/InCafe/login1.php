<?php
session_start();
include("koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LOGIN</title>

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- emoji reaction -->
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=62a9e344c15a8900199d23a8&product=inline-reaction-buttons" async="async"></script>

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <!-- Sidebar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand" href="index3.php"><strong>INCAFE</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index3.php">BERANDA<span class="sr-only">(current)</span></a>
                </li>
                <?php if (isset($_SESSION["user"])) : ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">KELUAR</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li class="nav-item"><a class="nav-link" href="view1.php">MASUK/DAFTAR</a></li>
                <?php endif ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">KATEGORI</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">CAFE TERMURAH</a>
                        <a class="dropdown-item" href="#">CAFE TERMAHAL</a>
                        <a class="dropdown-item" href="#">CAFE TERJAUH</a>
                        <a class="dropdown-item" href="#">CAFE TERDEKAT</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index3.php">SIMPAN</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
        </div>
    </nav><br><br>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <div class="panel panel-default col-12">
                    <div class="panel-heading">
                        <h3 class="panel-title">Login User</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password">
                            </div>
                            <button class="btn btn-primary" name="login">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    //jika ada tombol login(tombol login ditekan)
    if (isset($_POST["login"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];
        //lakukan query ngecek akun di tabel pelanggan di database
        $ambil = $koneksi->query("SELECT * FROM user
				WHERE email_user='$email' AND password='$password'");
        //ngitung akun yang terambil
        $akunyangcocok = $ambil->num_rows;
        //jika 1 akun yan cocok, maka diloginkan
        if ($akunyangcocok == 1) {
            while ($row = $ambil->fetch_assoc()) {
                if ($row['status'] == 'verified') {
                    //mendapatkan akun dalam bentuk array
                    $akun = $ambil->fetch_assoc();
                    //simpan di session pelanggan
                    $_SESSION["user"] = $akun;
                    echo "<script>alert('Anda berhasil login.');</script>";
                    echo "<script>location='index3.php';</script>";
                } else {
                    echo "<script>alert('Please verify your account');</script>";
                }
            }
        } else {
            //anda gagal login
            echo "<script>alert('anda gagal login, periksa akun Anda');</script>";
            echo "<script>location='login.php';</script>";
        }
    }

    ?>
</body>

<head>