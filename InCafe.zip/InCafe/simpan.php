<?php
session_start();

//echo "<pre>";
//print_r($_SESSION['keranjang]);
//echo "</per>";
include("koneksi.php");

//jika belom login, maka dilarikan ke login.php
if (!isset($_SESSION["user"])) {
    echo "<script>alert('Silahkan login!');</script>";
    echo "<script>location='login.php';</script>";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Simpan</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
</head>

<body>
    <!--Navbar-->

    <nav class="navbar navbar-default">
        <div class="container">
            <ul class="nav navbar-nav">

                <li><a href="index.php">Home</a></li>
                <!-- jika sudah login(ada session user) -->
                <?php if (isset($_SESSION["user"])) : ?>
                    <li><a href="logout.php">Logout</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li><a href="view.php">Login/Daftar</a></li>
                <?php endif ?>
                <li><a href="simpan.php">Simpan</a></li>
                <div class="container">
                    <form action="pencarian.php" method="get" class="navbar-form navbar-right">
                        <input type="text" class="form-control" name="keyword">
                        <button class="btn btn-primary">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                        <br>
                    </form>
                </div>

            </ul>
        </div>
    </nav>
    <section class="konten">
        <div class="container">
            <h1>Simpan</h1>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center align-middle">No</th>
                        <th class="text-center align-middle">Nama Cafe</th>
                        <th class="text-center align-middle">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $nomor = 1; ?>
                    <?php foreach ($_SESSION["simpan"] as $id_tambah_cafe => $jumlah) : ?>

                        <?php
                        $ambil = $koneksi->query("SELECT * FROM tambah_cafe 
                        WHERE id_tambah_cafe='$id_tambah_cafe'");
                        $pecah = $ambil->fetch_assoc();
                        //echo "<pre>";
                        //print_r($pecah);
                        //echo "</pre>";
                        ?>
                        <tr class="text-center align-middle">
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['nama_toko_cafe']; ?></td>
                            <td>
                                <a href="hapuspost.php?id=<?php echo $id_tambah_cafe ?>" class="btn-danger btn">hapus</a>
                                <a href="detail.php?id=<?php echo $id_tambah_cafe ?>" class="btn btn-primary">Detail</a>
                            </td>
                        </tr>
                        <?php $nomor++ ?>
                    <?php endforeach ?>

                </tbody>
            </table>
            <a href="index.php" class="btn btn-primary">Kembali ke Home</a>
        </div>

</body>

<head>