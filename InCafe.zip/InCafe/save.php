<?php
session_start();
$id_tambah_cafe = $_GET['id'];
if (isset($_SESSION['simpan'][$id_tambah_cafe])){
   $_SESSION['simpan'][$id_tambah_cafe]+=1;
}
else {
    $_SESSION['simpan'][$id_tambah_cafe] = 1;
}
//echo "<pre>";
//print_r($_SESSION);
//echo "</per>";

//setelah di save, dilarikan ke halaman simpan
echo "<script>alert('Informasi cafe telah ditambahkan ke Simpan.');</script>";
echo "<script>location='simpan1.php';</script>";
