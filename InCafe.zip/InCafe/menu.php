    <!--Navbar-->
    <nav class="navbar navbar-default">
        <div class="container">

            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="daftar.php">Daftar</a></li>
                <li><a href="simpan.php">Simpan</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>