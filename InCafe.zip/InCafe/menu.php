<body>
    <!--Navbar-->
    <nav class="navbar navbar-default">
        <div class="container">
        <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <!-- jika sudah login(ada session pelanggan) -->
            <?php if (isset($_SESSION["user"])) : ?>
                <li><a href="logout.php">Logout</i></a></li>
                <!-- selain itu (blm login//blm ada session pelanggan) -->
            <?php else : ?>
                <li><a href="login.php">Login</i></a></li>
                <li><a href="daftar.php">Daftar</a></li>
            <?php endif ?>
            <li><a href="save.php">Simpan</a></li>
            <form action="pencarian.php" method="get" class="navbar-form navbar-right">
                <input type="text" class="form-control" name="keyword">
                <button class="btn btn-primary">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                <br>
            </form>

        </ul>
        </div>
    </nav>