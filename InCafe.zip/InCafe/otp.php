<?php
include("koneksi.php");?>

<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome-animation.min.css">

</head>

<body>
    <!--Navbar-->   
    <nav class="navbar navbar-default">
    <div class="container">
        <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <!-- jika sudah login(ada session pelanggan) -->
            <?php if (isset($_SESSION["user"])) : ?>
                <li><a href="logout.php">Logout</a></li>
                <!-- selain itu (blm login//blm ada session pelanggan) -->
            <?php else : ?>
                <li><a href="view.php">Login/Daftar</a></li>
            <?php endif ?>
            <li><a href="save.php">Simpan</a></li>
            <div class= "container">
            <form action="pencarian.php" method="get" class="navbar-form navbar-right">
                <input type="text" class="form-control" name="keyword">
                <button class="btn btn-primary">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                <br>
            </form>
            </div>
        </ul>
        </div>
    </nav>
    <div class="container">
        <div class="row">
        <div class="col-sm-4 col-md-offset-4">

<form action="" method="POST" autocomplete="" class="form-horizontal formx" role="form" enctype='multipart/form-data'>
    <center>
        <a target="_blank" href="https://www.youtube.com/channel/UCh3zMcSY8-XpetX_Zq29e_w?view_as=subscriber?sub_confirmation=1"><img src="assets/img/logo/lokon!d.png" width="80px"></a>
    </center>
    <h2 class="text-center">Verifikasi Kode OTP </h2>
    <?php
    // if (isset($_SESSION['info'])) {
    ?>
        <div class="alert alert-success text-center">
        Kami telah mengirimkan kode OTP verifikasi ke email Anda
        </div>
    <?php
    //}
    ?>
    
    <div class="form-group">
        <input class="form-control" type="number" name="otp" placeholder="Kode OTP Verifikasi" required>
    </div>
    <div class="form-group">
        <button type="submit" class="form-control btn btn-sm btn-primary" name="check" style="border-radius: 20px;border: 2px solid #EFE4E4;"><i class="fa fa-send (alias) faa-tada animated-hover"></i> Kirim</button>
    </div>
    <center>
        <hr>
        <p>
            Develop by <a class="label btn-danger" target="_blank" href="https://www.youtube.com/channel/UCh3zMcSY8-XpetX_Zq29e_w?view_as=subscriber?sub_confirmation=1" title="Klik Saya">InCafe</a>
        </p>
    </center>
</form>
</div>
        
                        <?php
                        mysqli_report(MYSQLI_REPORT_OFF);
                        //jika ada tombol daftar
                        if (isset($_POST["check"])) {
                            //mengambil isian dari form pendaftaran
                            
                           
                            $otp_code = $_POST["otp"];
    $check_code = "SELECT * FROM user WHERE otp = $otp_code";
    $ambil = $koneksi->query($check_code);
    $yangcocok = $ambil->num_rows;
    if ($yangcocok == 1) {
       
        $code = 0;
        $status = 'verified';
        $update_otp = "UPDATE user SET otp = $code, status = '$status' WHERE otp = $otp_code";
        $yangcocok2 = $koneksi->query($update_otp);
         
        if ($yangcocok2) {
            
            echo "<script>location='login.php';</script>";

            exit();
        } else {
            $errors['otp-error'] = "Gagal saat memperbarui kode!";
        }
    } else {
        $errors['otp-error'] = "Anda memasukkan kode yang salah!";
    }
                        }
                        ?>
                    
        </div>
    </div>
</body>

<head>