<?php
session_start();
//koneksi ke database
include("koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>INCAFE</title>

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- emoji reaction -->
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=62a9e344c15a8900199d23a8&product=inline-reaction-buttons" async="async"></script>

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <!-- Sidebar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand" href="index3.php"><strong>INCAFE</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index3.php">BERANDA<span class="sr-only">(current)</span></a>
                </li>
                <?php if (isset($_SESSION["user"])) : ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">KELUAR</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li class="nav-item"><a class="nav-link" href="view1.php">MASUK/DAFTAR</a></li>
                <?php endif ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="kategori.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">KATEGORI</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="kategori.php">CAFE MURAH</a>
                        <a class="dropdown-item" href="kategori2.php">CAFE MAHAL</a>
                        <a class="dropdown-item" href="cafeterjauh.php">CAFE TERJAUH</a>
                        <a class="dropdown-item" href="cafeterdekat.php">CAFE TERDEKAT</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="simpan1.php">SIMPAN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tentang.php">TENTANG KAMI</a>
                </li>
            </ul>
            <form action="pencarian1.php" method="get" class="form-inline my-2 my-lg-0">
                <input type="text" class="form-control mr-sm-2" name="keyword">
                <button class="btn btn-outline-dark my-2 my-sm-0">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                <br>
            </form>
        </div>
    </nav><br><br>

    <div class="container mt-4">

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="carouselExampleIndicators" data-slide-to="1" class="active"></li>
                <li data-target="carouselExampleIndicators" data-slide-to="2" class="active"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/3.png" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/1.png" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/2.png" class="d-block w-100" alt="...">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <section class="konten">
            <div class="container">
                <div class="row">
                    <?php $ambil = $koneksi->query("SELECT * FROM tambah_cafe"); ?>
                    <?php while ($percafe = $ambil->fetch_assoc()) { ?>
                        <div class="card-body">
                            <div class="card ml-4" style="width: 16rem;">
                                <div class="thumbnail">
                                    <img src="fotocafe/<?php echo $percafe['foto']; ?>" class="card-img-top" alt="">
                                    <div class="caption mt-3">
                                        <center>
                                            <h5><?php echo $percafe['nama_toko_cafe']; ?></h5>
                                        </center>
                                        <div class="mb-3">
                                            <center>
                                                <a href="detailcafe.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class="btn btn-info btn-sm"><i class="fas fa-solid fa-eye"></i></a>
                                                <a href="save.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class=" btn btn-success btn-sm"><i class="fas fa-fw fa-bookmark"></i></a>
                                            </center>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>

        <tbody>
            <?php
            $batas = 9;
            $halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
            $halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

            $previous = $halaman - 1;
            $next = $halaman + 1;

            $data = mysqli_query($koneksi, "select * from tambah_cafe");
            $jumlah_data = mysqli_num_rows($data);
            $total_halaman = ceil($jumlah_data / $batas);

            $data_cafe = mysqli_query($koneksi, "select * from tambah_cafe limit $halaman_awal, $batas");
            $nomor = $halaman_awal + 1;
            while ($d = mysqli_fetch_array($data_cafe)) { ?>
            <?php } ?>
        </tbody>
        <nav>
            <ul class="pagination justify-content-center">
                <li class="page-item">
                    <a class="page-link" <?php if ($halaman > 1) {
                                                echo "href='?halaman=$previous'";
                                            } ?>>Previous</a>
                </li>
                <?php
                for ($x = 1; $x <= $total_halaman; $x++) {
                ?>
                    <li class="page-item"><a class="page-link" href="?halaman=<?php echo $x ?>"><?php echo $x; ?></a></li>
                <?php
                }
                ?>
                <li class="page-item">
                    <a class="page-link" <?php if ($halaman < $total_halaman) {
                                                echo "href='?halaman=$next'";
                                            } ?>>Next</a>
                </li>
            </ul>
        </nav>

        <!-- Bootstrap core JavaScript-->
        <script src="assets/vendor/jquery/jquery.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="assets/js/sb-admin-2.min.js"></script>

        <!-- Page level plugins -->
        <script src="assets/vendor/chart.js/Chart.min.js"></script>

        <!-- Page level custom scripts -->
        <script src="assets/js/demo/chart-area-demo.js"></script>
        <script src="assets/js/demo/chart-pie-demo.js"></script>

</body>

</html>
<center>
    <div class="sharethis-inline-reaction-buttons"></div>
    <div class="button-feedback">
        <a href="https://forms.gle/YGTVQ8FXWCncG3ic6"><button class="btn btn-primary mt-5">Feedback</button></a>
    </div>
</center>