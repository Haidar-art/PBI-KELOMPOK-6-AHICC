<?php
session_start();
//koneksi ke database
include("koneksi.php");
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <br>
    <title>InCafe</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
    <!-- emoji reaction -->
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=62a9e344c15a8900199d23a8&product=inline-reaction-buttons" async="async"></script>
    <!-- Custom styles for this template -->
    <link href="admin/assets/css/carousel.css" rel="stylesheet">
</head>

<body>
    <!--Navbar-->
    <nav class="navbar navbar-default">
        <div class="container">
            <ul class="nav navbar-nav">

                <li><a href="index.php">Home</a></li>
                <!-- jika sudah login(ada session user) -->
                <?php if (isset($_SESSION["user"])) : ?>
                    <li><a href="logout.php">Logout</a></li>
                    <!-- selain itu (blm login//blm ada session user) -->
                <?php else : ?>
                    <li><a href="view.php">Login/Daftar</a></li>
                <?php endif ?>
                <li><a href="simpan.php">Simpan</a></li>
                <li><a href="kategori.php">Kategori</a></li>
                <div class="container">
                    <form action="pencarian.php" method="get" class="navbar-form navbar-right">
                        <input type="text" class="form-control" name="keyword">
                        <button class="btn btn-primary">Cari Cafe<i class="glyphicon glyphicon-search"></i></button>
                        <br>
                    </form>
                </div>

            </ul>
        </div>

    </nav>
    <!--Konten-->
    <section class="konten">
        <div class="container">
            <h1>Informasi Cafe</h1>
            <div class="row">
                <?php $ambil = $koneksi->query("SELECT * FROM tambah_cafe"); ?>
                <?php while ($percafe = $ambil->fetch_assoc()) { ?>
                    <div class="col-md-6">
                        <div class="thumbnail">
                            <img src="fotocafe/<?php echo $percafe['foto']; ?>" alt="">
                            <div class="caption">
                                <center>
                                    <h3><?php echo $percafe['nama_toko_cafe']; ?></h3>
                                </center>
                                <center><a href="detail.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class="btn btn-info">Detail</a>
                                    <a href="save.php?id=<?php echo $percafe['id_tambah_cafe']; ?>" class=" btn btn-success">Simpan</a>
                                </center>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
</body>

<head>

    <center>
        <div class="sharethis-inline-reaction-buttons"></div>
    </center>