<?php

include("koneksi.php");
?>
<?php
require_once "smtp/PHPMailerAutoload.php";
function smtp_mailer($to, $subject, $msg)
{

    //echo "<script>alert('Email in function...');</script>";
    $mail = new PHPMailer();
    //$mail->SMTPDebug  = 3;
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->IsHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Username = "stairstepsdesigns@gmail.com";
    //$mail->Password = "Stair@1234";vqldcpyyblmhovor
    $mail->Password = "vqldcpyyblmhovor";

    $mail->SetFrom("stairstepsdesigns@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions = array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => false
    ));
    if (!$mail->Send()) {
        echo $mail->ErrorInfo;

        echo "<script>alert('Email sending fail...');</script>";
    } else {
        return "<script>alert('Email successfully sent...');</script>";
    }
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome-animation.min.css">

</head>

<body>
    <!--Navbar-->
    <nav class="navbar navbar-default">
        <div class="container">
            <ul class="nav navbar-nav">

                <body>
                    <li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
                </body>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-md-offset-4">
                <form method="POST" autocomplete="" class="form-horizontal formx" role="form">
                    <center>
                        <img src="fotocafe/Logo_InCafe.png" width="150px">
                    </center>
                    <h2 class="text-center">Form Registrasi</h2>
                    <p class="text-center">Silahkan lengkapi form di bawah ini!</p>
                    <div class="form-group">
                        <input class="form-control" type="text" name="nama" placeholder="Nama Lengkap" required value=>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Email" required value>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="number" name="no_telp" placeholder="No.Telepon" required>
                    </div>
                    <div class="form-group">
                        <Center>
                            <button class="btn btn-sm btn-primary" type="submit" name="daftar" style="width: 150px;border-radius: 20px;border: 2px solid #EFE4E4;"><i class="fa fa-user-plus faa-tada animated-hover"></i> Registrasi</button>
                            <a href="google.php" class="btn btn-danger btn-success" style="width: 150px;border-radius: 20px;border: 2px solid #EFE4E4;"><i class="fa fa-google faa-tada animated-hover"></i> Google</a>
                        </Center>
                    </div>
                    <div class="link login-link text-center">Sudah memiliki akun?
                        <a href="login.php" class="label btn-warning" title="Klik Saya">Login Sekarang!</a>
                    </div>

                </form>
            </div>
            <?php
            //jika ada tombol daftar
            if (isset($_POST["daftar"])) {
                //mengambil isian dari form pendaftaran
                $nama = $_POST["nama"];
                $email = $_POST["email"];
                $password = $_POST["password"];
                $no_telp = $_POST["no_telp"];
                //cek apakah email sudah digunakan
                $ambil = $koneksi->query("SELECT * FROM user WHERE email_user='$email'");
                $yangcocok = $ambil->num_rows;
                if ($yangcocok == 1) {
                    echo "<script>alert('Pendaftaran gagal, email sudah digunakan. Silahkan menggunakan email lain.');</script>";
                    echo "<script>location='daftar.php';</script>";
                } else {
                    $code = rand(999999, 111111);
                    //query insert ke tabel pelanggan
                    $koneksi->query("INSERT INTO user 
									(nama_user, email_user, password, no_telp,otp)
									VALUES('$nama','$email','$password','$no_telp',$code) ");
                    $to_email = $email;
                    $subject1 = "InCafe";
                    $html = "Use this Code for Verification: \n $code";

                    echo smtp_mailer($to_email, $subject1, $html);
                    echo "<script>location='otp.php';</script>";
                    echo "<script>alert('Pendaftaran sukses! Silahkan login');</script>";
                }
            }
            ?>
        </div>
    </div>
</body>

<head>